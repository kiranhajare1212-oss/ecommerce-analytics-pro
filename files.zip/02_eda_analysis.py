"""
E-Commerce Analytics Project
Script 2: Exploratory Data Analysis (EDA) & Insights
Produces console summary + saves analysis outputs
"""

import sqlite3
import pandas as pd
import numpy as np
import os

DB_PATH  = "../data/ecommerce.db"
DATA_DIR = "../data"
OUT_DIR  = "../data/analysis_outputs"
os.makedirs(OUT_DIR, exist_ok=True)

# ── LOAD DATA ────────────────────────────────────────────────
def load_data():
    customers   = pd.read_csv(f"{DATA_DIR}/customers.csv",   parse_dates=["registration_date"])
    products    = pd.read_csv(f"{DATA_DIR}/products.csv")
    orders      = pd.read_csv(f"{DATA_DIR}/orders.csv",      parse_dates=["order_date","delivery_date"])
    order_items = pd.read_csv(f"{DATA_DIR}/order_items.csv")
    returns     = pd.read_csv(f"{DATA_DIR}/returns.csv",     parse_dates=["return_date"])
    return customers, products, orders, order_items, returns

# ── BUILD SQLITE DB ──────────────────────────────────────────
def build_db(customers, products, orders, order_items, returns):
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    customers.to_sql("customers",   conn, index=False, if_exists="replace")
    products.to_sql("products",     conn, index=False, if_exists="replace")
    orders.to_sql("orders",         conn, index=False, if_exists="replace")
    order_items.to_sql("order_items", conn, index=False, if_exists="replace")
    returns.to_sql("returns",       conn, index=False, if_exists="replace")

    # Run views SQL
    views_path = "../sql/03_views.sql"
    if os.path.exists(views_path):
        with open(views_path) as f:
            sql_text = f.read()
        for stmt in sql_text.split(";"):
            stmt = stmt.strip()
            if stmt:
                try:
                    conn.execute(stmt)
                except Exception as e:
                    pass
    conn.commit()
    conn.close()
    print(f"✅ SQLite DB created: {os.path.abspath(DB_PATH)}")

# ── ANALYSIS FUNCTIONS ───────────────────────────────────────
def revenue_overview(orders):
    delivered = orders[orders["status"] != "Cancelled"]
    print("\n" + "═"*55)
    print("  REVENUE OVERVIEW")
    print("═"*55)
    print(f"  Total Orders (excl. cancelled) : {len(delivered):,}")
    print(f"  Total Gross Revenue            : ₹{delivered['order_total'].sum():,.2f}")
    print(f"  Average Order Value            : ₹{delivered['order_total'].mean():,.2f}")
    print(f"  Median Order Value             : ₹{delivered['order_total'].median():,.2f}")
    print(f"  Total Shipping Revenue         : ₹{delivered['shipping_fee'].sum():,.2f}")
    print(f"  Orders With Coupon             : {delivered['coupon_used'].sum():,} ({delivered['coupon_used'].mean()*100:.1f}%)")

    monthly = (delivered
               .set_index("order_date")
               .resample("ME")["order_total"]
               .agg(["sum","count","mean"])
               .rename(columns={"sum":"revenue","count":"orders","mean":"aov"}))
    monthly.to_csv(f"{OUT_DIR}/monthly_revenue.csv")
    print(f"\n  Monthly revenue saved → {OUT_DIR}/monthly_revenue.csv")
    return monthly

def category_analysis(orders, order_items, products):
    delivered = orders[orders["status"] != "Cancelled"][["order_id"]]
    df = (delivered
          .merge(order_items, on="order_id")
          .merge(products[["product_id","category","cost_price"]], on="product_id"))
    cat = df.groupby("category").agg(
        units_sold    = ("quantity",   "sum"),
        revenue       = ("line_total", "sum"),
        cogs          = ("cost_price", lambda x: (x * df.loc[x.index,"quantity"]).sum()),
    ).assign(
        gross_profit = lambda d: d["revenue"] - d["cogs"],
        gp_margin    = lambda d: (d["gross_profit"] / d["revenue"] * 100).round(2),
    ).sort_values("revenue", ascending=False)

    print("\n" + "═"*55)
    print("  CATEGORY PERFORMANCE")
    print("═"*55)
    print(cat[["units_sold","revenue","gross_profit","gp_margin"]].to_string())
    cat.to_csv(f"{OUT_DIR}/category_performance.csv")
    return cat

def rfm_analysis(orders, customers):
    snapshot = pd.Timestamp("2025-01-01")
    delivered = orders[orders["status"] != "Cancelled"]
    rfm = delivered.groupby("customer_id").agg(
        recency   = ("order_date",  lambda x: (snapshot - x.max()).days),
        frequency = ("order_id",    "nunique"),
        monetary  = ("order_total", "sum"),
    ).reset_index()

    rfm["r"] = pd.qcut(rfm["recency"],   5, labels=[5,4,3,2,1])
    rfm["f"] = pd.qcut(rfm["frequency"].rank(method="first"), 5, labels=[1,2,3,4,5])
    rfm["m"] = pd.qcut(rfm["monetary"],  5, labels=[1,2,3,4,5])

    rfm["r"] = rfm["r"].astype(int)
    rfm["f"] = rfm["f"].astype(int)
    rfm["m"] = rfm["m"].astype(int)
    rfm["rfm_score"] = rfm["r"] + rfm["f"] + rfm["m"]

    def segment(row):
        r, f = row["r"], row["f"]
        if r >= 4 and f >= 4: return "Champions"
        if r >= 3 and f >= 3: return "Loyal"
        if r >= 4 and f <= 2: return "New/Recent"
        if r <= 2 and f >= 3: return "At Risk"
        if r <= 2 and f <= 2: return "Lost"
        if row["m"] >= 4:     return "High Spender"
        return "Potential Loyal"

    rfm["segment"] = rfm.apply(segment, axis=1)

    seg_summary = rfm.groupby("segment").agg(
        customers    = ("customer_id", "count"),
        avg_recency  = ("recency",   "mean"),
        avg_freq     = ("frequency", "mean"),
        avg_monetary = ("monetary",  "mean"),
        total_rev    = ("monetary",  "sum"),
    ).round(2).sort_values("total_rev", ascending=False)

    print("\n" + "═"*55)
    print("  RFM SEGMENT SUMMARY")
    print("═"*55)
    print(seg_summary.to_string())
    rfm.to_csv(f"{OUT_DIR}/rfm_scores.csv", index=False)
    seg_summary.to_csv(f"{OUT_DIR}/rfm_segments.csv")
    return rfm, seg_summary

def return_analysis(returns, orders, order_items, products):
    delivered_ids = set(orders[orders["status"] == "Delivered"]["order_id"])
    return_rate = len(returns) / len(delivered_ids) * 100

    print("\n" + "═"*55)
    print("  RETURNS ANALYSIS")
    print("═"*55)
    print(f"  Return Rate         : {return_rate:.2f}%")
    print(f"  Total Returns       : {len(returns):,}")
    print(f"  Total Refunded      : ₹{returns['refund_amount'].sum():,.2f}")
    print(f"\n  Top Return Reasons:")
    reasons = returns["reason"].value_counts()
    print(reasons.to_string())
    returns.to_csv(f"{OUT_DIR}/returns_detail.csv", index=False)

def cohort_retention(orders):
    delivered = orders[orders["status"] != "Cancelled"].copy()
    delivered["cohort_month"] = (delivered
        .groupby("customer_id")["order_date"]
        .transform("min")
        .dt.to_period("M"))
    delivered["order_month"] = delivered["order_date"].dt.to_period("M")
    delivered["month_number"] = (
        (delivered["order_month"] - delivered["cohort_month"])
        .apply(lambda x: x.n)
    )

    cohort_data = (delivered
                   .groupby(["cohort_month","month_number"])["customer_id"]
                   .nunique()
                   .reset_index(name="customers"))

    cohort_sizes = cohort_data[cohort_data["month_number"] == 0].set_index("cohort_month")["customers"]
    cohort_pivot = cohort_data.pivot(index="cohort_month", columns="month_number", values="customers")
    retention = cohort_pivot.divide(cohort_sizes, axis=0).round(3)

    print("\n" + "═"*55)
    print("  COHORT RETENTION (first 6 months, sample)")
    print("═"*55)
    print(retention.iloc[:6, :7].to_string())
    retention.to_csv(f"{OUT_DIR}/cohort_retention.csv")
    print(f"\n  Full cohort table saved → {OUT_DIR}/cohort_retention.csv")
    return retention

def top_products(orders, order_items, products):
    delivered = orders[orders["status"] != "Cancelled"][["order_id"]]
    df = delivered.merge(order_items, on="order_id").merge(products, on="product_id")
    top = (df.groupby(["product_id","product_name","category","brand"])
           .agg(units_sold=("quantity","sum"), revenue=("line_total","sum"))
           .sort_values("revenue", ascending=False)
           .head(20))
    top.to_csv(f"{OUT_DIR}/top_products.csv")
    print(f"\n  Top products saved → {OUT_DIR}/top_products.csv")
    return top

# ── MAIN ─────────────────────────────────────────────────────
def main():
    print("\n🔄 Loading data...")
    customers, products, orders, order_items, returns = load_data()

    print("🔄 Building SQLite database...")
    build_db(customers, products, orders, order_items, returns)

    revenue_overview(orders)
    category_analysis(orders, order_items, products)
    rfm_analysis(orders, customers)
    return_analysis(returns, orders, order_items, products)
    cohort_retention(orders)
    top_products(orders, order_items, products)

    print("\n" + "═"*55)
    print("  ✅ EDA COMPLETE — outputs saved to:")
    print(f"     {os.path.abspath(OUT_DIR)}")
    print("═"*55)

if __name__ == "__main__":
    main()
