"""
E-Commerce Analytics Project
Script 3: Excel Report Generator
Creates a professional multi-sheet Excel workbook with:
  - Executive Summary (KPIs)
  - Monthly Revenue Trend
  - Category Performance
  - Top Products
  - RFM Segments
  - Returns Analysis
  - Cohort Retention Heatmap
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.chart.series import DataPoint
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule
import os

DATA_DIR = "../data"
OUT_FILE = "../excel/ecommerce_analytics_report.xlsx"
os.makedirs("../excel", exist_ok=True)

# ── COLOR PALETTE ─────────────────────────────────────────────
DARK_NAVY    = "0D1B2A"
MID_BLUE     = "1B5E8B"
ACCENT_TEAL  = "00B4D8"
ACCENT_GREEN = "2DC653"
ACCENT_RED   = "E63946"
ACCENT_AMBER = "F4A261"
LIGHT_GRAY   = "F0F4F8"
WHITE        = "FFFFFF"
TEXT_DARK    = "0D1B2A"
TEXT_MID     = "4A5568"

# ── STYLE HELPERS ─────────────────────────────────────────────
def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, size=11, color=TEXT_DARK, italic=False):
    return Font(bold=bold, size=size, color=color, italic=italic,
                name="Calibri")

def border_all(thin=True):
    s = Side(border_style="thin" if thin else "medium", color="CBD5E0")
    return Border(left=s, right=s, top=s, bottom=s)

def border_bottom(color="CBD5E0"):
    return Border(bottom=Side(border_style="medium", color=color))

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def set_col_width(ws, col_letter, width):
    ws.column_dimensions[col_letter].width = width

def header_row(ws, row, headers, col_fills, start_col=1):
    for i, (h, fc) in enumerate(zip(headers, col_fills)):
        cell = ws.cell(row=row, column=start_col+i, value=h)
        cell.font      = font(bold=True, color=WHITE, size=10)
        cell.fill      = fill(fc)
        cell.alignment = align("center")
        cell.border    = border_all()

def data_row(ws, row, values, bg=WHITE, start_col=1, bold=False):
    for i, v in enumerate(values):
        cell = ws.cell(row=row, column=start_col+i, value=v)
        cell.font      = font(bold=bold, size=10)
        cell.fill      = fill(bg)
        cell.alignment = align("right" if isinstance(v, (int,float)) else "left")
        cell.border    = border_all()

def title_cell(ws, row, col, text, size=16, color=DARK_NAVY, bold=True, bg=WHITE):
    c = ws.cell(row=row, column=col, value=text)
    c.font      = font(bold=bold, size=size, color=color)
    c.fill      = fill(bg)
    c.alignment = align("left", "center")
    return c

def currency_fmt(ws, row, col):
    ws.cell(row=row, column=col).number_format = '#,##0.00'

def pct_fmt(ws, row, col):
    ws.cell(row=row, column=col).number_format = '0.00%'

# ── LOAD DATA ─────────────────────────────────────────────────
def load():
    orders      = pd.read_csv(f"{DATA_DIR}/orders.csv",     parse_dates=["order_date"])
    order_items = pd.read_csv(f"{DATA_DIR}/order_items.csv")
    products    = pd.read_csv(f"{DATA_DIR}/products.csv")
    customers   = pd.read_csv(f"{DATA_DIR}/customers.csv",  parse_dates=["registration_date"])
    returns     = pd.read_csv(f"{DATA_DIR}/returns.csv",    parse_dates=["return_date"])
    rfm         = pd.read_csv(f"{DATA_DIR}/analysis_outputs/rfm_scores.csv")
    monthly     = pd.read_csv(f"{DATA_DIR}/analysis_outputs/monthly_revenue.csv",
                               parse_dates=["order_date"])
    cohort      = pd.read_csv(f"{DATA_DIR}/analysis_outputs/cohort_retention.csv",
                               index_col=0)
    return orders, order_items, products, customers, returns, rfm, monthly, cohort

# ── SHEET 1: EXECUTIVE SUMMARY ────────────────────────────────
def build_summary(wb, orders, order_items, products, customers, returns, rfm):
    ws = wb.create_sheet("📊 Executive Summary")
    ws.sheet_view.showGridLines = False

    # Banner
    ws.merge_cells("A1:J1")
    c = ws["A1"]
    c.value     = "🛒  E-COMMERCE ANALYTICS DASHBOARD  —  FY 2022-2024"
    c.font      = Font(bold=True, size=18, color=WHITE, name="Calibri")
    c.fill      = fill(DARK_NAVY)
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 40

    ws.merge_cells("A2:J2")
    ws["A2"].fill = fill(MID_BLUE)
    ws.row_dimensions[2].height = 6

    delivered = orders[orders["status"] != "Cancelled"]
    total_rev   = delivered["order_total"].sum()
    total_ord   = delivered["order_id"].nunique()
    total_cust  = delivered["customer_id"].nunique()
    aov         = total_rev / total_ord
    return_rate = len(returns) / len(delivered[delivered["status"]=="Delivered"]) * 100
    canc_rate   = (orders["status"] == "Cancelled").sum() / len(orders) * 100
    total_units = order_items.merge(delivered[["order_id"]], on="order_id")["quantity"].sum()

    kpis = [
        ("Total Revenue",     f"₹{total_rev/1e7:.2f} Cr",    DARK_NAVY),
        ("Total Orders",      f"{total_ord:,}",               MID_BLUE),
        ("Unique Customers",  f"{total_cust:,}",              "1A5276"),
        ("Avg Order Value",   f"₹{aov:,.0f}",                ACCENT_TEAL[:6]),
        ("Units Sold",        f"{total_units:,}",             "145A32"),
        ("Return Rate",       f"{return_rate:.1f}%",          ACCENT_RED),
        ("Cancellation Rate", f"{canc_rate:.1f}%",            "7D3C98"),
        ("Active Products",   f"{products['is_active'].sum():,}", "117A65"),
    ]

    ws.row_dimensions[3].height = 8
    ws.row_dimensions[4].height = 70
    ws.row_dimensions[5].height = 8

    kpi_cols = ["A","B","C","D","E","F","G","H"]
    for i, (label, value, color) in enumerate(kpis):
        col = kpi_cols[i]
        col_idx = i + 1
        ws.merge_cells(f"{col}4:{col}4")
        cell = ws.cell(row=4, column=col_idx)
        ws.cell(row=4, column=col_idx, value=f"{label}\n{value}")
        cell.font      = Font(bold=True, size=12, color=WHITE, name="Calibri")
        cell.fill      = fill(color)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border    = Border(
            left=Side("thin", color="FFFFFF"),
            right=Side("thin", color="FFFFFF"),
        )

    # Section header
    ws.row_dimensions[6].height = 20
    title_cell(ws, 6, 1, "  Monthly Revenue Trend (2022-2024)", size=12, color=WHITE, bg=MID_BLUE)
    ws.merge_cells("A6:J6")

    return ws


# ── SHEET 2: MONTHLY REVENUE ──────────────────────────────────
def build_monthly(wb, orders):
    ws = wb.create_sheet("📈 Monthly Revenue")
    ws.sheet_view.showGridLines = False

    delivered = orders[orders["status"] != "Cancelled"].copy()
    delivered["ym"] = delivered["order_date"].dt.to_period("M").astype(str)
    monthly = (delivered.groupby("ym")
               .agg(orders=("order_id","nunique"),
                    revenue=("order_total","sum"),
                    customers=("customer_id","nunique"),
                    aov=("order_total","mean"))
               .reset_index()
               .rename(columns={"ym":"Month"}))
    monthly["revenue"]    = monthly["revenue"].round(2)
    monthly["aov"]        = monthly["aov"].round(2)
    monthly["mom_growth"] = monthly["revenue"].pct_change().fillna(0).round(4)

    # Banner
    ws.merge_cells("A1:H1")
    c = ws["A1"]
    c.value     = "Monthly Revenue & Order Trends"
    c.font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    c.fill      = fill(DARK_NAVY)
    c.alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    headers = ["Month","Orders","Revenue (₹)","Customers","AOV (₹)","MoM Growth"]
    col_fills = [DARK_NAVY, MID_BLUE, ACCENT_TEAL, MID_BLUE, ACCENT_TEAL, MID_BLUE]
    header_row(ws, 2, headers, col_fills)

    for r_idx, row in monthly.iterrows():
        bg = WHITE if r_idx % 2 == 0 else LIGHT_GRAY
        vals = [row["Month"], row["orders"], row["revenue"],
                row["customers"], row["aov"], row["mom_growth"]]
        data_row(ws, r_idx+3, vals, bg=bg)
        ws.cell(r_idx+3, 3).number_format = '#,##0.00'
        ws.cell(r_idx+3, 5).number_format = '#,##0.00'
        ws.cell(r_idx+3, 6).number_format = '0.00%'

    # Chart
    chart = LineChart()
    chart.title  = "Monthly Revenue Trend"
    chart.style  = 10
    chart.y_axis.title = "Revenue (₹)"
    chart.x_axis.title = "Month"
    chart.height = 15
    chart.width  = 25

    n = len(monthly) + 2
    data_ref  = Reference(ws, min_col=3, min_row=2, max_row=n)
    cats_ref  = Reference(ws, min_col=1, min_row=3, max_row=n)
    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats_ref)
    ws.add_chart(chart, "H3")

    for c_idx, w in zip("ABCDEFG", [14,10,16,12,14,12,14]):
        ws.column_dimensions[c_idx].width = w

    return ws


# ── SHEET 3: CATEGORY PERFORMANCE ────────────────────────────
def build_category(wb, orders, order_items, products):
    ws = wb.create_sheet("🗂 Category Performance")
    ws.sheet_view.showGridLines = False

    delivered = orders[orders["status"] != "Cancelled"][["order_id"]]
    df = (delivered
          .merge(order_items, on="order_id")
          .merge(products[["product_id","category","cost_price"]], on="product_id"))
    cat = (df.groupby("category").agg(
        units_sold  = ("quantity",   "sum"),
        revenue     = ("line_total", "sum"),
    ).reset_index())
    cat["cogs"]         = df.groupby("category").apply(
        lambda g: (g["quantity"] * g["cost_price"]).sum()
    ).values
    cat["gross_profit"] = cat["revenue"] - cat["cogs"]
    cat["gp_margin"]    = cat["gross_profit"] / cat["revenue"]
    cat = cat.sort_values("revenue", ascending=False).reset_index(drop=True)

    ws.merge_cells("A1:G1")
    ws["A1"].value     = "Category Performance — Revenue & Margin"
    ws["A1"].font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    ws["A1"].fill      = fill(DARK_NAVY)
    ws["A1"].alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    headers   = ["Category","Units Sold","Revenue (₹)","COGS (₹)","Gross Profit (₹)","GP Margin %","Rank"]
    col_fills = [DARK_NAVY,MID_BLUE,ACCENT_TEAL,MID_BLUE,ACCENT_GREEN,ACCENT_AMBER,DARK_NAVY]
    header_row(ws, 2, headers, col_fills)

    for i, row in cat.iterrows():
        bg = WHITE if i % 2 == 0 else LIGHT_GRAY
        vals = [row["category"], int(row["units_sold"]),
                row["revenue"], row["cogs"], row["gross_profit"],
                row["gp_margin"], i+1]
        data_row(ws, i+3, vals, bg=bg)
        for c_idx in [3,4,5]:
            ws.cell(i+3, c_idx).number_format = '#,##0.00'
        ws.cell(i+3, 6).number_format = '0.00%'

    # Bar chart
    n = len(cat) + 2
    chart = BarChart()
    chart.type   = "col"
    chart.title  = "Revenue by Category"
    chart.style  = 10
    chart.y_axis.title = "Revenue (₹)"
    chart.height = 14
    chart.width  = 22
    data_ref = Reference(ws, min_col=3, min_row=2, max_row=n)
    cats_ref = Reference(ws, min_col=1, min_row=3, max_row=n)
    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats_ref)
    ws.add_chart(chart, "I2")

    for c_idx, w in zip("ABCDEFG", [22,12,16,16,18,12,8]):
        ws.column_dimensions[c_idx].width = w
    return ws


# ── SHEET 4: TOP PRODUCTS ─────────────────────────────────────
def build_top_products(wb, orders, order_items, products):
    ws = wb.create_sheet("🏆 Top Products")
    ws.sheet_view.showGridLines = False

    delivered = orders[orders["status"] != "Cancelled"][["order_id"]]
    df = (delivered
          .merge(order_items, on="order_id")
          .merge(products, on="product_id"))
    top = (df.groupby(["product_id","product_name","category","brand"])
           .agg(units_sold=("quantity","sum"),
                revenue=("line_total","sum"),
                avg_discount=("discount_pct","mean"))
           .reset_index()
           .sort_values("revenue", ascending=False)
           .head(25)
           .reset_index(drop=True))
    top["avg_discount"] = top["avg_discount"] * 100

    ws.merge_cells("A1:H1")
    ws["A1"].value     = "Top 25 Products by Revenue"
    ws["A1"].font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    ws["A1"].fill      = fill(DARK_NAVY)
    ws["A1"].alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    headers   = ["Rank","Product Name","Category","Brand","Units Sold","Revenue (₹)","Avg Discount %","Revenue Share %"]
    col_fills = [DARK_NAVY,MID_BLUE,MID_BLUE,MID_BLUE,ACCENT_TEAL,ACCENT_TEAL,ACCENT_AMBER,ACCENT_GREEN]
    header_row(ws, 2, headers, col_fills)

    total_rev = top["revenue"].sum()
    for i, row in top.iterrows():
        bg = WHITE if i % 2 == 0 else LIGHT_GRAY
        rev_share = row["revenue"] / total_rev * 100
        vals = [i+1, row["product_name"], row["category"], row["brand"],
                int(row["units_sold"]), row["revenue"],
                round(row["avg_discount"],1), round(rev_share,2)]
        data_row(ws, i+3, vals, bg=bg)
        ws.cell(i+3, 6).number_format = '#,##0.00'
        ws.cell(i+3, 7).number_format = '0.0'
        ws.cell(i+3, 8).number_format = '0.00'

    # Data bars on revenue
    ws.conditional_formatting.add(
        f"F3:F{len(top)+2}",
        DataBarRule(start_type="min", start_value=0,
                    end_type="max", end_value=None,
                    color=ACCENT_TEAL)
    )

    for c_idx, w in zip("ABCDEFGH", [6,38,20,12,12,16,16,14]):
        ws.column_dimensions[c_idx].width = w
    return ws


# ── SHEET 5: RFM SEGMENTS ─────────────────────────────────────
def build_rfm(wb, rfm):
    ws = wb.create_sheet("👥 RFM Segments")
    ws.sheet_view.showGridLines = False

    seg = (rfm.groupby("segment")
           .agg(customers=("customer_id","count"),
                avg_recency=("recency","mean"),
                avg_frequency=("frequency","mean"),
                avg_monetary=("monetary","mean"),
                total_revenue=("monetary","sum"))
           .round(2)
           .reset_index()
           .sort_values("total_revenue", ascending=False))

    ws.merge_cells("A1:G1")
    ws["A1"].value     = "RFM Customer Segmentation"
    ws["A1"].font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    ws["A1"].fill      = fill(DARK_NAVY)
    ws["A1"].alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    headers   = ["Segment","Customers","Avg Recency (Days)","Avg Frequency","Avg Monetary (₹)","Total Revenue (₹)","% of Revenue"]
    col_fills = [DARK_NAVY,MID_BLUE,ACCENT_AMBER,ACCENT_TEAL,ACCENT_GREEN,ACCENT_GREEN,MID_BLUE]
    header_row(ws, 2, headers, col_fills)

    total = seg["total_revenue"].sum()
    seg_colors = {
        "Champions":       "145A32",
        "Loyal":           "1A5276",
        "New/Recent":      "117A65",
        "Potential Loyal": "6C3483",
        "High Spender":    "D35400",
        "At Risk":         "922B21",
        "Lost":            "566573",
    }
    for i, row in seg.iterrows():
        bg = seg_colors.get(row["segment"], MID_BLUE)
        pct = row["total_revenue"] / total * 100
        vals = [row["segment"], int(row["customers"]),
                round(row["avg_recency"],0), round(row["avg_frequency"],1),
                row["avg_monetary"], row["total_revenue"], round(pct,2)]
        r = i + 3
        for j, v in enumerate(vals):
            cell = ws.cell(row=r, column=j+1, value=v)
            cell.font      = Font(bold=(j==0), size=10,
                                  color=WHITE if j==0 else TEXT_DARK, name="Calibri")
            cell.fill      = fill(bg) if j==0 else fill(WHITE if i%2==0 else LIGHT_GRAY)
            cell.alignment = align("right" if isinstance(v,(int,float)) else "left")
            cell.border    = border_all()
        ws.cell(r, 5).number_format = '#,##0.00'
        ws.cell(r, 6).number_format = '#,##0.00'
        ws.cell(r, 7).number_format = '0.00'

    # Pie chart
    chart = PieChart()
    chart.title  = "Revenue by RFM Segment"
    chart.height = 14
    chart.width  = 18
    n = len(seg) + 2
    data_ref = Reference(ws, min_col=6, min_row=2, max_row=n)
    cats_ref = Reference(ws, min_col=1, min_row=3, max_row=n)
    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats_ref)
    ws.add_chart(chart, "I3")

    for c_idx, w in zip("ABCDEFG",[20,12,20,14,18,18,14]):
        ws.column_dimensions[c_idx].width = w
    return ws


# ── SHEET 6: RETURNS ANALYSIS ─────────────────────────────────
def build_returns(wb, returns, orders):
    ws = wb.create_sheet("↩ Returns Analysis")
    ws.sheet_view.showGridLines = False

    merged = returns.merge(orders[["order_id","order_date","order_total","channel","country"]],
                           on="order_id", how="left")
    merged["days_to_return"] = (merged["return_date"] - merged["order_date"]).dt.days

    ws.merge_cells("A1:F1")
    ws["A1"].value     = "Returns & Refunds Analysis"
    ws["A1"].font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    ws["A1"].fill      = fill(DARK_NAVY)
    ws["A1"].alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    # KPI summary
    kpis = [
        ("Total Returns",      len(returns)),
        ("Total Refunded (₹)", returns["refund_amount"].sum()),
        ("Avg Refund (₹)",     returns["refund_amount"].mean()),
        ("Avg Days to Return", merged["days_to_return"].mean()),
    ]
    ws.merge_cells("A2:F2")
    ws["A2"].fill = fill(LIGHT_GRAY)
    for i, (k, v) in enumerate(kpis):
        c = ws.cell(row=3, column=i*2+1, value=k)
        c.font = font(bold=True, size=9, color=TEXT_MID)
        c.fill = fill(LIGHT_GRAY)
        c2 = ws.cell(row=4, column=i*2+1,
                     value=round(v,2) if isinstance(v,float) else v)
        c2.font = Font(bold=True, size=13, color=DARK_NAVY, name="Calibri")
        c2.fill = fill(WHITE)

    # By reason
    by_reason = (returns.groupby("reason")
                 .agg(count=("return_id","count"),
                      total_refund=("refund_amount","sum"),
                      avg_refund=("refund_amount","mean"))
                 .sort_values("count", ascending=False)
                 .reset_index())

    headers = ["Return Reason","Count","Total Refund (₹)","Avg Refund (₹)","% of Total"]
    col_fills = [DARK_NAVY,MID_BLUE,ACCENT_RED,ACCENT_AMBER,MID_BLUE]
    header_row(ws, 6, headers, col_fills)

    total_returns = len(returns)
    for i, row in by_reason.iterrows():
        bg = WHITE if i%2==0 else LIGHT_GRAY
        pct = row["count"] / total_returns * 100
        vals = [row["reason"], int(row["count"]),
                row["total_refund"], round(row["avg_refund"],2), round(pct,2)]
        data_row(ws, i+7, vals, bg=bg)
        ws.cell(i+7, 3).number_format = '#,##0.00'
        ws.cell(i+7, 4).number_format = '#,##0.00'

    for c_idx, w in zip("ABCDE",[30,10,18,18,12]):
        ws.column_dimensions[c_idx].width = w
    return ws


# ── SHEET 7: COHORT RETENTION ─────────────────────────────────
def build_cohort(wb, cohort):
    ws = wb.create_sheet("🔁 Cohort Retention")
    ws.sheet_view.showGridLines = False

    ws.merge_cells("A1:N1")
    ws["A1"].value     = "Customer Cohort Retention Heatmap"
    ws["A1"].font      = Font(bold=True, size=15, color=WHITE, name="Calibri")
    ws["A1"].fill      = fill(DARK_NAVY)
    ws["A1"].alignment = align("center","center")
    ws.row_dimensions[1].height = 35

    ws.cell(2, 1, "Cohort ↓  /  Month →")
    ws.cell(2,1).font = font(bold=True, size=10, color=WHITE)
    ws.cell(2,1).fill = fill(MID_BLUE)
    ws.cell(2,1).alignment = align("center")

    cols = sorted([c for c in cohort.columns if str(c).isdigit()], key=int)[:13]
    for j, col in enumerate(cols):
        c = ws.cell(2, j+2, f"Month {col}")
        c.font      = font(bold=True, size=10, color=WHITE)
        c.fill      = fill(MID_BLUE)
        c.alignment = align("center")

    for i, (idx, row_data) in enumerate(cohort.iterrows()):
        r = i + 3
        label = ws.cell(r, 1, str(idx))
        label.font      = font(bold=True, size=9, color=WHITE)
        label.fill      = fill(DARK_NAVY)
        label.alignment = align("center")
        for j, col in enumerate(cols):
            val = row_data.get(int(col) if str(col).isdigit() else col, None)
            c = ws.cell(r, j+2)
            if pd.notna(val):
                c.value = round(float(val), 3)
                c.number_format = "0.0%"
                # Manual color gradient: green → red
                pct = float(val)
                if pct >= 0.8:   bg = "145A32"
                elif pct >= 0.5: bg = "1E8449"
                elif pct >= 0.3: bg = "D4EFDF"
                elif pct >= 0.1: bg = "FAD7A0"
                elif pct > 0:    bg = "F1948A"
                else:            bg = "E8DAEF"
                c.fill = fill(bg)
                c.font = Font(size=9, bold=(pct>=0.5),
                              color=WHITE if pct>=0.5 else DARK_NAVY,
                              name="Calibri")
            else:
                c.fill = fill(LIGHT_GRAY)
            c.alignment = align("center")
            c.border    = border_all()

    ws.column_dimensions["A"].width = 14
    for j in range(len(cols)):
        ws.column_dimensions[get_column_letter(j+2)].width = 10

    return ws


# ── MAIN ──────────────────────────────────────────────────────
def main():
    print("📊 Loading data...")
    orders, order_items, products, customers, returns, rfm, monthly, cohort = load()

    print("📒 Building Excel workbook...")
    wb = Workbook()
    wb.remove(wb.active)  # Remove default sheet

    print("  → Executive Summary...")
    build_summary(wb, orders, order_items, products, customers, returns, rfm)
    print("  → Monthly Revenue...")
    build_monthly(wb, orders)
    print("  → Category Performance...")
    build_category(wb, orders, order_items, products)
    print("  → Top Products...")
    build_top_products(wb, orders, order_items, products)
    print("  → RFM Segments...")
    build_rfm(wb, rfm)
    print("  → Returns Analysis...")
    build_returns(wb, returns, orders)
    print("  → Cohort Retention...")
    build_cohort(wb, cohort)

    wb.save(OUT_FILE)
    print(f"\n✅ Excel report saved: {os.path.abspath(OUT_FILE)}")

if __name__ == "__main__":
    main()
