-- ============================================================
-- E-COMMERCE ANALYTICS PROJECT
-- File: 03_views.sql
-- Purpose: Create reporting views for Power BI / dashboards
-- ============================================================

-- ── VIEW 1: vw_monthly_revenue ──────────────────────────────
DROP VIEW IF EXISTS vw_monthly_revenue;
CREATE VIEW vw_monthly_revenue AS
SELECT
    strftime('%Y', order_date)        AS year,
    strftime('%m', order_date)        AS month,
    strftime('%Y-%m', order_date)     AS year_month,
    COUNT(DISTINCT order_id)          AS total_orders,
    COUNT(DISTINCT customer_id)       AS unique_customers,
    ROUND(SUM(order_total), 2)        AS gross_revenue,
    ROUND(AVG(order_total), 2)        AS avg_order_value,
    SUM(coupon_used)                  AS coupons_used
FROM orders
WHERE status != 'Cancelled'
GROUP BY year, month, year_month;


-- ── VIEW 2: vw_product_performance ─────────────────────────
DROP VIEW IF EXISTS vw_product_performance;
CREATE VIEW vw_product_performance AS
SELECT
    p.product_id,
    p.product_name,
    p.category,
    p.brand,
    p.selling_price,
    p.cost_price,
    p.rating,
    p.reviews_count,
    COALESCE(s.units_sold, 0)         AS units_sold,
    COALESCE(s.revenue, 0)            AS revenue,
    COALESCE(s.orders_count, 0)       AS orders_count,
    COALESCE(s.avg_discount, 0)       AS avg_discount_pct,
    ROUND(COALESCE(s.revenue, 0)
          - p.cost_price * COALESCE(s.units_sold, 0), 2) AS gross_profit
FROM products p
LEFT JOIN (
    SELECT
        oi.product_id,
        SUM(oi.quantity)                AS units_sold,
        ROUND(SUM(oi.line_total), 2)    AS revenue,
        COUNT(DISTINCT oi.order_id)     AS orders_count,
        ROUND(AVG(oi.discount_pct)*100,2) AS avg_discount
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.status != 'Cancelled'
    GROUP BY oi.product_id
) s ON p.product_id = s.product_id;


-- ── VIEW 3: vw_customer_summary ─────────────────────────────
DROP VIEW IF EXISTS vw_customer_summary;
CREATE VIEW vw_customer_summary AS
SELECT
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.city,
    c.country,
    c.acquisition_channel,
    c.age_group,
    c.gender,
    c.registration_date,
    COALESCE(s.total_orders, 0)        AS total_orders,
    COALESCE(s.total_revenue, 0)       AS total_revenue,
    COALESCE(s.avg_order_value, 0)     AS avg_order_value,
    s.first_order_date,
    s.last_order_date,
    CASE
        WHEN s.total_orders IS NULL    THEN 'Inactive'
        WHEN s.total_orders = 1        THEN 'One-Time'
        WHEN s.total_orders <= 4       THEN 'Occasional'
        WHEN s.total_orders <= 9       THEN 'Regular'
        ELSE 'VIP'
    END AS buyer_segment,
    CASE
        WHEN COALESCE(s.total_revenue,0) >= 50000 THEN 'Platinum'
        WHEN COALESCE(s.total_revenue,0) >= 20000 THEN 'Gold'
        WHEN COALESCE(s.total_revenue,0) >= 5000  THEN 'Silver'
        ELSE 'Bronze'
    END AS value_tier
FROM customers c
LEFT JOIN (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id)       AS total_orders,
        ROUND(SUM(order_total), 2)     AS total_revenue,
        ROUND(AVG(order_total), 2)     AS avg_order_value,
        MIN(order_date)                AS first_order_date,
        MAX(order_date)                AS last_order_date
    FROM orders
    WHERE status != 'Cancelled'
    GROUP BY customer_id
) s ON c.customer_id = s.customer_id;


-- ── VIEW 4: vw_returns_analysis ─────────────────────────────
DROP VIEW IF EXISTS vw_returns_analysis;
CREATE VIEW vw_returns_analysis AS
SELECT
    r.return_id,
    r.order_id,
    r.customer_id,
    r.return_date,
    r.reason,
    r.refund_amount,
    r.return_status,
    o.order_date,
    o.order_total,
    o.channel,
    o.country,
    julianday(r.return_date) - julianday(o.order_date) AS days_to_return
FROM returns r
JOIN orders o ON r.order_id = o.order_id;


-- ── VIEW 5: vw_daily_kpis ───────────────────────────────────
DROP VIEW IF EXISTS vw_daily_kpis;
CREATE VIEW vw_daily_kpis AS
SELECT
    order_date                         AS date,
    COUNT(DISTINCT order_id)           AS orders,
    COUNT(DISTINCT customer_id)        AS customers,
    ROUND(SUM(order_total), 2)         AS revenue,
    ROUND(AVG(order_total), 2)         AS aov,
    SUM(CASE WHEN status='Cancelled' THEN 1 ELSE 0 END) AS cancellations,
    SUM(coupon_used)                   AS coupons
FROM orders
GROUP BY order_date;
