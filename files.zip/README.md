# 🛒 End-to-End E-Commerce Analytics Project

> A complete data analytics portfolio project using **SQL · Python · Excel · Power BI**  
> Covering data generation, exploration, KPI reporting, customer segmentation, and dashboard design.

---

## 📌 Project Overview

This project simulates a real-world e-commerce analytics pipeline for a multi-region online retailer. It covers the full lifecycle from raw data to business insights:

| Layer | Tool | What It Does |
|---|---|---|
| Data Generation | Python | Synthetic realistic dataset (12K orders, 2K customers) |
| Data Storage | SQLite / CSV | Relational schema with indexes and views |
| Analytics Queries | SQL | 20+ business queries (revenue, RFM, cohorts, ops) |
| Exploratory Analysis | Python (pandas) | EDA, RFM scoring, cohort retention |
| Reporting | Excel (openpyxl) | 7-sheet workbook with charts and heatmaps |
| Dashboard | Power BI | 5-page interactive dashboard with DAX measures |

---

## 📂 Project Structure

```
ecommerce_analytics/
│
├── data/                          # Generated datasets
│   ├── customers.csv              # 2,000 customers
│   ├── products.csv               # ~113 products across 6 categories
│   ├── orders.csv                 # 12,000 orders (2022-2024)
│   ├── order_items.csv            # 25,000+ line items
│   ├── returns.csv                # ~693 return records
│   ├── ecommerce.db               # SQLite database (auto-generated)
│   └── analysis_outputs/          # EDA output CSVs
│       ├── monthly_revenue.csv
│       ├── category_performance.csv
│       ├── rfm_scores.csv
│       ├── rfm_segments.csv
│       ├── cohort_retention.csv
│       ├── top_products.csv
│       └── returns_detail.csv
│
├── sql/
│   ├── 01_schema.sql              # Table definitions & indexes
│   ├── 02_analytics_queries.sql   # 20+ analytical queries (5 sections)
│   └── 03_views.sql               # Reporting views for Power BI
│
├── python/
│   ├── 01_generate_data.py        # Synthetic data generator
│   ├── 02_eda_analysis.py         # EDA, RFM, cohort analysis
│   └── 03_excel_report.py         # Multi-sheet Excel report builder
│
├── excel/
│   └── ecommerce_analytics_report.xlsx   # 7-sheet Excel workbook
│
├── powerbi/
│   ├── POWERBI_SETUP.md           # Step-by-step Power BI guide
│   └── theme.json                 # Custom Power BI color theme
│
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
```bash
pip install pandas numpy openpyxl
```

### Run in Order
```bash
# Step 1 — Generate synthetic data
cd python
python 01_generate_data.py

# Step 2 — Run EDA + build SQLite DB
python 02_eda_analysis.py

# Step 3 — Generate Excel report
python 03_excel_report.py
```

---

## 🗃️ Dataset Schema

### `customers`
| Column | Type | Description |
|---|---|---|
| customer_id | VARCHAR | Primary key (CUST00001 format) |
| first_name, last_name | VARCHAR | Customer name |
| email, phone | VARCHAR | Contact info |
| city, state, country | VARCHAR | Location (India, USA, UK, UAE, Singapore) |
| registration_date | DATE | When they signed up |
| acquisition_channel | VARCHAR | Organic / Paid / Social / Email / Referral / Direct |
| age_group | VARCHAR | 18-24, 25-34, 35-44, 45-54, 55+ |
| gender | VARCHAR | Male / Female / Other |

### `products`
| Column | Type | Description |
|---|---|---|
| product_id | VARCHAR | Primary key |
| product_name | VARCHAR | Name with variant (Standard/Pro/Lite) |
| category | VARCHAR | Electronics, Clothing, Home & Kitchen, Books, Sports & Fitness, Beauty & Health |
| brand | VARCHAR | 8 fictional brands |
| selling_price | DECIMAL | Customer-facing price |
| cost_price | DECIMAL | COGS (35–60% of selling price) |
| stock_quantity | INT | Current inventory |
| rating | DECIMAL | 3.0–5.0 |
| is_active | SMALLINT | 1 = active |

### `orders`
| Column | Type | Description |
|---|---|---|
| order_id | VARCHAR | Primary key |
| customer_id | VARCHAR | FK → customers |
| order_date | DATE | Purchase date |
| delivery_date | DATE | Actual delivery (null if not delivered) |
| status | VARCHAR | Delivered / Shipped / Processing / Cancelled |
| payment_method | VARCHAR | Credit Card / Debit Card / UPI / Net Banking / Wallet / COD |
| channel | VARCHAR | Acquisition channel for this order |
| order_total | DECIMAL | Total value of order |
| shipping_fee | DECIMAL | 0 / 49 / 99 / 149 |
| coupon_used | SMALLINT | 1 if coupon applied |

### `order_items`
| Column | Type | Description |
|---|---|---|
| item_id | VARCHAR | Primary key |
| order_id | VARCHAR | FK → orders |
| product_id | VARCHAR | FK → products |
| quantity | INT | Units purchased |
| unit_price | DECIMAL | Price at time of purchase |
| discount_pct | DECIMAL | 0–20% |
| line_total | DECIMAL | unit_price × qty × (1 - discount) |

### `returns`
| Column | Type | Description |
|---|---|---|
| return_id | VARCHAR | Primary key |
| order_id | VARCHAR | FK → orders |
| customer_id | VARCHAR | FK → customers |
| return_date | DATE | Date of return |
| reason | VARCHAR | 7 possible reasons |
| refund_amount | DECIMAL | 50–100% of order total |
| return_status | VARCHAR | Refunded / Processing / Rejected |

---

## 📊 SQL Analytics Queries (02_analytics_queries.sql)

### Section A — Revenue & Sales
| Query | Description |
|---|---|
| A1 | Monthly revenue, orders, customers, AOV trend |
| A2 | Category revenue with COGS and gross profit margin |
| A3 | Top 20 best-selling products |
| A4 | Sales channel performance with revenue share |
| A5 | Payment method mix |

### Section B — Customer Analytics
| Query | Description |
|---|---|
| B1 | Customer Lifetime Value with segmentation |
| B2 | RFM segmentation using NTILE window functions |
| B3 | New vs returning customers monthly |
| B4 | Cohort retention analysis (monthly) |

### Section C — Geography & Demographics
| Query | Description |
|---|---|
| C1 | Revenue by country |
| C2 | Top 20 revenue cities |
| C3 | Revenue by age group × gender |

### Section D — Operational KPIs
| Query | Description |
|---|---|
| D1 | Order status distribution |
| D2 | Average delivery time by country |
| D3 | Return rate by category |
| D4 | Return reason breakdown |
| D5 | Inventory health (low stock alerts) |

### Section E — Advanced Window Functions
| Query | Description |
|---|---|
| E1 | YTD revenue + MoM growth % using LAG |
| E2 | Category revenue rank per month using RANK() |
| E3 | Customer purchase gap analysis |
| E4 | Discount band impact on revenue |

---

## 📈 Excel Report (7 Sheets)

| Sheet | Contents |
|---|---|
| 📊 Executive Summary | KPI banner cards, banner styling |
| 📈 Monthly Revenue | Trend table + line chart |
| 🗂 Category Performance | Revenue + margin table + bar chart |
| 🏆 Top Products | Top 25 by revenue with data bars |
| 👥 RFM Segments | Segment table with color-coded rows + pie chart |
| ↩ Returns Analysis | Reason breakdown + KPI summary |
| 🔁 Cohort Retention | Full cohort heatmap with conditional color gradient |

---

## 📉 Power BI Dashboard (5 Pages)

| Page | Key Visuals |
|---|---|
| Executive Overview | KPI cards, revenue line, channel bar, order status donut |
| Product Analytics | Top products bar, category treemap, rating scatter |
| Customer Analytics | RFM segments, map, new vs returning, age/gender matrix |
| Returns & Operations | Return reason bar, return rate trend, delivery gauge |
| Cohort Analysis | Retention heatmap matrix, cohort retention lines |

See `powerbi/POWERBI_SETUP.md` for full connection and DAX setup.

---

## 🔍 Key Business Insights (Sample Findings)

- **Electronics** dominates revenue at ~58% of total with ~49.6% gross margin
- **Champions segment** (RFM) represents only ~20% of customers but 28%+ of revenue
- **8% return rate** with "Duplicate order" and "Defective product" as top reasons
- **25.8% of orders** used a coupon — worth monitoring against margin impact
- **Paid Search and Organic** drive the highest AOV channels

---

## 🛠️ Tech Stack

| Tool | Version | Purpose |
|---|---|---|
| Python | 3.9+ | Data generation, EDA, Excel generation |
| pandas | 1.5+ | Data manipulation |
| openpyxl | 3.0+ | Excel workbook creation |
| SQLite | Built-in | Relational database |
| SQL | ANSI + SQLite | Analytics queries |
| Excel | 2019 / 365 | Report consumption |
| Power BI Desktop | Latest | Interactive dashboards |

---

## 📄 License

MIT License — free to use, adapt, and extend for portfolio or learning purposes.

---

## 🤝 Contributing

Pull requests welcome! Ideas for extension:
- Add ML-based churn prediction (scikit-learn)
- Streamlit web dashboard version
- dbt transformation layer
- Add forecasting with Prophet or statsmodels

---

*Built as an end-to-end analytics portfolio project demonstrating SQL, Python, Excel, and Power BI skills.*
