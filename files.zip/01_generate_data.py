"""
E-Commerce Analytics Project
Script 1: Synthetic Data Generation
Generates realistic datasets: customers, products, orders, order_items, returns
"""

import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random
import csv

random.seed(42)
np.random.seed(42)

OUTPUT_DIR = "../data"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── CONFIG ──────────────────────────────────────────────────────────────────
N_CUSTOMERS   = 2000
N_PRODUCTS    = 150
N_ORDERS      = 12000
START_DATE    = datetime(2022, 1, 1)
END_DATE      = datetime(2024, 12, 31)

# ── LOOKUP DATA ──────────────────────────────────────────────────────────────
FIRST_NAMES = ["Aarav","Aisha","Arjun","Priya","Rahul","Sneha","Vikram","Meera",
               "Karan","Divya","Rohit","Anjali","Amit","Pooja","Sanjay","Neha",
               "James","Emma","Oliver","Sophia","Liam","Ava","Noah","Isabella",
               "William","Mia","Benjamin","Charlotte","Elijah","Amelia",
               "Carlos","Maria","Pedro","Ana","Luis","Sofia","Juan","Elena",
               "Wei","Lin","Fang","Mei","Jing","Yang","Hao","Xin"]

LAST_NAMES  = ["Sharma","Patel","Singh","Kumar","Gupta","Verma","Agarwal","Joshi",
               "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller",
               "Davis","Wilson","Anderson","Taylor","Thomas","Martinez","Hernandez",
               "Chen","Wang","Liu","Zhang","Li","Wu","Zhao","Sun"]

CITIES = [
    ("Mumbai","Maharashtra","India"),("Delhi","Delhi","India"),
    ("Bangalore","Karnataka","India"),("Hyderabad","Telangana","India"),
    ("Chennai","Tamil Nadu","India"),("Pune","Maharashtra","India"),
    ("Kolkata","West Bengal","India"),("Ahmedabad","Gujarat","India"),
    ("New York","New York","USA"),("Los Angeles","California","USA"),
    ("Chicago","Illinois","USA"),("Houston","Texas","USA"),
    ("London","England","UK"),("Manchester","England","UK"),
    ("Singapore","Central","Singapore"),("Dubai","Dubai","UAE"),
]

CATEGORIES = {
    "Electronics":     ["Smartphone","Laptop","Tablet","Smartwatch","Earbuds",
                        "Portable Speaker","Camera","Power Bank","Monitor","Keyboard"],
    "Clothing":        ["T-Shirt","Jeans","Dress","Jacket","Sneakers",
                        "Formal Shirt","Kurta","Saree","Hoodie","Shorts"],
    "Home & Kitchen":  ["Mixer Grinder","Air Purifier","Pressure Cooker","Bedsheet",
                        "Pillow Set","Table Lamp","Wall Clock","Cookware Set",
                        "Storage Box","Curtains"],
    "Books":           ["Data Science Handbook","Python Crash Course","Rich Dad Poor Dad",
                        "Atomic Habits","The Alchemist","Zero to One",
                        "Power of Subconscious Mind","Clean Code","Deep Work","Ikigai"],
    "Sports & Fitness":["Yoga Mat","Dumbbells","Resistance Bands","Treadmill",
                        "Cycling Shorts","Protein Powder","Jump Rope","Foam Roller",
                        "Gym Bag","Sports Shoes"],
    "Beauty & Health": ["Face Serum","Sunscreen SPF50","Hair Oil","Perfume",
                        "Electric Toothbrush","Vitamin C Tablets","Face Wash",
                        "Moisturiser","Lip Balm","Shampoo"],
}

PRICE_RANGES = {
    "Electronics":     (1500, 85000),
    "Clothing":        (299,  5999),
    "Home & Kitchen":  (499,  15000),
    "Books":           (199,  999),
    "Sports & Fitness":(299,  45000),
    "Beauty & Health": (149,  3999),
}

PAYMENT_METHODS = ["Credit Card","Debit Card","UPI","Net Banking","Wallet","COD"]
CHANNELS        = ["Organic","Paid Search","Social Media","Email","Referral","Direct"]
STATUSES        = ["Delivered","Shipped","Processing","Cancelled"]
STATUS_WEIGHTS  = [0.72, 0.10, 0.08, 0.10]

# ── HELPERS ──────────────────────────────────────────────────────────────────
def rand_date(start, end):
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, delta))

def rand_email(first, last, idx):
    domains = ["gmail.com","yahoo.com","outlook.com","hotmail.com","proton.me"]
    return f"{first.lower()}.{last.lower()}{idx}@{random.choice(domains)}"

def rand_phone():
    return f"+91-{random.randint(70000,99999)}{random.randint(10000,99999)}"

# ── 1. CUSTOMERS ─────────────────────────────────────────────────────────────
print("Generating customers...")
customers = []
for i in range(1, N_CUSTOMERS + 1):
    first = random.choice(FIRST_NAMES)
    last  = random.choice(LAST_NAMES)
    city, state, country = random.choice(CITIES)
    reg_date = rand_date(START_DATE, END_DATE - timedelta(days=30))
    customers.append({
        "customer_id":    f"CUST{i:05d}",
        "first_name":     first,
        "last_name":      last,
        "email":          rand_email(first, last, i),
        "phone":          rand_phone(),
        "city":           city,
        "state":          state,
        "country":        country,
        "registration_date": reg_date.strftime("%Y-%m-%d"),
        "acquisition_channel": random.choice(CHANNELS),
        "age_group":      random.choice(["18-24","25-34","35-44","45-54","55+"]),
        "gender":         random.choice(["Male","Female","Other"]),
    })

df_customers = pd.DataFrame(customers)
df_customers.to_csv(f"{OUTPUT_DIR}/customers.csv", index=False)
print(f"  → {len(df_customers)} customers saved.")

# ── 2. PRODUCTS ───────────────────────────────────────────────────────────────
print("Generating products...")
products = []
pid = 1
for cat, items in CATEGORIES.items():
    lo, hi = PRICE_RANGES[cat]
    for item in items:
        for variant in range(1, random.randint(2, 4)):
            price = round(random.uniform(lo, hi), -1)
            cost  = round(price * random.uniform(0.35, 0.60), 2)
            products.append({
                "product_id":   f"PROD{pid:04d}",
                "product_name": f"{item} {'Pro' if variant==2 else 'Lite' if variant==3 else 'Standard'}",
                "category":     cat,
                "brand":        random.choice(["ShopX","TechNova","StyleHub","HomeEase","FitLife","GlowUp","BrandA","BrandB"]),
                "selling_price":price,
                "cost_price":   cost,
                "stock_quantity": random.randint(0, 500),
                "rating":       round(random.uniform(3.0, 5.0), 1),
                "reviews_count":random.randint(5, 4000),
                "is_active":    random.choice([1,1,1,0]),
            })
            pid += 1

df_products = pd.DataFrame(products)
df_products.to_csv(f"{OUTPUT_DIR}/products.csv", index=False)
print(f"  → {len(df_products)} products saved.")

# ── 3. ORDERS + ORDER_ITEMS ───────────────────────────────────────────────────
print("Generating orders and order items...")
product_ids = df_products["product_id"].tolist()
customer_ids = df_customers["customer_id"].tolist()

orders, order_items = [], []
item_id = 1

for o in range(1, N_ORDERS + 1):
    cust_id   = random.choice(customer_ids)
    cust_row  = df_customers[df_customers["customer_id"] == cust_id].iloc[0]
    reg_date  = datetime.strptime(cust_row["registration_date"], "%Y-%m-%d")
    order_date = rand_date(max(reg_date, START_DATE), END_DATE)

    status    = random.choices(STATUSES, weights=STATUS_WEIGHTS)[0]
    n_items   = random.choices([1,2,3,4,5], weights=[40,30,15,10,5])[0]
    items_sel = random.sample(product_ids, min(n_items, len(product_ids)))

    order_total = 0
    for pid in items_sel:
        prod = df_products[df_products["product_id"] == pid].iloc[0]
        qty  = random.randint(1, 4)
        disc = round(random.choice([0, 0, 0, 5, 10, 15, 20]) / 100, 2)
        unit_price   = prod["selling_price"]
        line_total   = round(unit_price * qty * (1 - disc), 2)
        order_total += line_total
        order_items.append({
            "item_id":        f"ITEM{item_id:07d}",
            "order_id":       f"ORD{o:07d}",
            "product_id":     pid,
            "quantity":       qty,
            "unit_price":     unit_price,
            "discount_pct":   disc,
            "line_total":     line_total,
        })
        item_id += 1

    ship_days   = random.randint(1, 7) if status == "Delivered" else None
    delivery_dt = (order_date + timedelta(days=ship_days)).strftime("%Y-%m-%d") if ship_days else None

    orders.append({
        "order_id":       f"ORD{o:07d}",
        "customer_id":    cust_id,
        "order_date":     order_date.strftime("%Y-%m-%d"),
        "delivery_date":  delivery_dt,
        "status":         status,
        "payment_method": random.choice(PAYMENT_METHODS),
        "channel":        random.choice(CHANNELS),
        "order_total":    round(order_total, 2),
        "shipping_fee":   round(random.choice([0, 0, 49, 99, 149]), 2),
        "coupon_used":    random.choice([0,0,0,1]),
        "city":           cust_row["city"],
        "country":        cust_row["country"],
    })

df_orders = pd.DataFrame(orders)
df_order_items = pd.DataFrame(order_items)
df_orders.to_csv(f"{OUTPUT_DIR}/orders.csv", index=False)
df_order_items.to_csv(f"{OUTPUT_DIR}/order_items.csv", index=False)
print(f"  → {len(df_orders)} orders, {len(df_order_items)} line items saved.")

# ── 4. RETURNS ────────────────────────────────────────────────────────────────
print("Generating returns...")
RETURN_REASONS = ["Defective product","Wrong item delivered","Not as described",
                  "Changed mind","Better price elsewhere","Damaged in transit","Duplicate order"]

delivered_orders = df_orders[df_orders["status"] == "Delivered"]["order_id"].tolist()
return_sample    = random.sample(delivered_orders, int(len(delivered_orders) * 0.08))

returns = []
for i, oid in enumerate(return_sample, 1):
    ord_row  = df_orders[df_orders["order_id"] == oid].iloc[0]
    ord_date = datetime.strptime(ord_row["order_date"], "%Y-%m-%d")
    ret_date = ord_date + timedelta(days=random.randint(5, 30))
    returns.append({
        "return_id":      f"RET{i:06d}",
        "order_id":       oid,
        "customer_id":    ord_row["customer_id"],
        "return_date":    ret_date.strftime("%Y-%m-%d"),
        "reason":         random.choice(RETURN_REASONS),
        "refund_amount":  round(ord_row["order_total"] * random.uniform(0.5, 1.0), 2),
        "return_status":  random.choice(["Refunded","Processing","Rejected"]),
    })

df_returns = pd.DataFrame(returns)
df_returns.to_csv(f"{OUTPUT_DIR}/returns.csv", index=False)
print(f"  → {len(df_returns)} returns saved.")

# ── SUMMARY ───────────────────────────────────────────────────────────────────
print("\n✅ Data generation complete!")
print(f"   Customers  : {len(df_customers)}")
print(f"   Products   : {len(df_products)}")
print(f"   Orders     : {len(df_orders)}")
print(f"   Order Items: {len(df_order_items)}")
print(f"   Returns    : {len(df_returns)}")
print(f"   Files saved to: {os.path.abspath(OUTPUT_DIR)}")
