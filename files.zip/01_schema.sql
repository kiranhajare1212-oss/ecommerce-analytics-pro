-- ============================================================
-- E-COMMERCE ANALYTICS PROJECT
-- File: 01_schema.sql
-- Purpose: Create all tables, indexes, and load data
-- Database: SQLite / PostgreSQL compatible (minor notes inline)
-- ============================================================

-- ── DROP EXISTING TABLES (for re-runs) ─────────────────────
DROP TABLE IF EXISTS returns;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- ── 1. CUSTOMERS ────────────────────────────────────────────
CREATE TABLE customers (
    customer_id        VARCHAR(10)  PRIMARY KEY,
    first_name         VARCHAR(50)  NOT NULL,
    last_name          VARCHAR(50)  NOT NULL,
    email              VARCHAR(100) NOT NULL UNIQUE,
    phone              VARCHAR(20),
    city               VARCHAR(50),
    state              VARCHAR(50),
    country            VARCHAR(50),
    registration_date  DATE,
    acquisition_channel VARCHAR(30),
    age_group          VARCHAR(10),
    gender             VARCHAR(10)
);

CREATE INDEX idx_customers_country    ON customers(country);
CREATE INDEX idx_customers_reg_date   ON customers(registration_date);
CREATE INDEX idx_customers_channel    ON customers(acquisition_channel);

-- ── 2. PRODUCTS ─────────────────────────────────────────────
CREATE TABLE products (
    product_id      VARCHAR(10)  PRIMARY KEY,
    product_name    VARCHAR(100) NOT NULL,
    category        VARCHAR(50),
    brand           VARCHAR(50),
    selling_price   DECIMAL(10,2) NOT NULL,
    cost_price      DECIMAL(10,2),
    stock_quantity  INT DEFAULT 0,
    rating          DECIMAL(3,1),
    reviews_count   INT DEFAULT 0,
    is_active       SMALLINT DEFAULT 1
);

CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_brand    ON products(brand);

-- ── 3. ORDERS ───────────────────────────────────────────────
CREATE TABLE orders (
    order_id        VARCHAR(12)  PRIMARY KEY,
    customer_id     VARCHAR(10)  REFERENCES customers(customer_id),
    order_date      DATE         NOT NULL,
    delivery_date   DATE,
    status          VARCHAR(20)  NOT NULL,
    payment_method  VARCHAR(20),
    channel         VARCHAR(30),
    order_total     DECIMAL(12,2),
    shipping_fee    DECIMAL(8,2) DEFAULT 0,
    coupon_used     SMALLINT DEFAULT 0,
    city            VARCHAR(50),
    country         VARCHAR(50)
);

CREATE INDEX idx_orders_customer  ON orders(customer_id);
CREATE INDEX idx_orders_date      ON orders(order_date);
CREATE INDEX idx_orders_status    ON orders(status);
CREATE INDEX idx_orders_channel   ON orders(channel);
CREATE INDEX idx_orders_country   ON orders(country);

-- ── 4. ORDER_ITEMS ──────────────────────────────────────────
CREATE TABLE order_items (
    item_id       VARCHAR(12)  PRIMARY KEY,
    order_id      VARCHAR(12)  REFERENCES orders(order_id),
    product_id    VARCHAR(10)  REFERENCES products(product_id),
    quantity      INT          NOT NULL CHECK (quantity > 0),
    unit_price    DECIMAL(10,2) NOT NULL,
    discount_pct  DECIMAL(5,2) DEFAULT 0,
    line_total    DECIMAL(12,2) NOT NULL
);

CREATE INDEX idx_items_order   ON order_items(order_id);
CREATE INDEX idx_items_product ON order_items(product_id);

-- ── 5. RETURNS ──────────────────────────────────────────────
CREATE TABLE returns (
    return_id     VARCHAR(10)  PRIMARY KEY,
    order_id      VARCHAR(12)  REFERENCES orders(order_id),
    customer_id   VARCHAR(10)  REFERENCES customers(customer_id),
    return_date   DATE,
    reason        VARCHAR(100),
    refund_amount DECIMAL(12,2),
    return_status VARCHAR(20)
);

CREATE INDEX idx_returns_customer ON returns(customer_id);
CREATE INDEX idx_returns_date     ON returns(return_date);
