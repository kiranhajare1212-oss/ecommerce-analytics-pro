# Power BI — E-Commerce Analytics Dashboard
## Setup Guide & DAX Measures Reference

---

## 📁 Data Source Setup

### Step 1 — Connect to SQLite Database
1. Open **Power BI Desktop**
2. Click **Home → Get Data → ODBC**
3. Select your SQLite ODBC driver and point to `data/ecommerce.db`
   - *Alternative*: Use **Get Data → Text/CSV** and load all CSVs from the `data/` folder

### Step 2 — Load These Tables
| Table | Source |
|---|---|
| customers | customers.csv |
| products | products.csv |
| orders | orders.csv |
| order_items | order_items.csv |
| returns | returns.csv |

### Step 3 — Build Relationships (Star Schema)
```
orders ──< order_items >── products
  │                            │
  ▼                            ▼
customers                   (category dim — optional)
  │
  ▼
returns
```

**Relationship Details:**
- `orders[order_id]` → `order_items[order_id]`  (1:Many)
- `products[product_id]` → `order_items[product_id]`  (1:Many)
- `customers[customer_id]` → `orders[customer_id]`  (1:Many)
- `orders[order_id]` → `returns[order_id]`  (1:Many)

### Step 4 — Create Date Table
In Power Query, add a new table:
```
Date = CALENDAR(DATE(2022,1,1), DATE(2024,12,31))
```
Then add columns:
- `Year = YEAR([Date])`
- `Month = MONTH([Date])`
- `MonthName = FORMAT([Date], "MMM")`
- `Quarter = "Q" & QUARTER([Date])`
- `YearMonth = FORMAT([Date], "YYYY-MM")`

Mark as Date Table → connect `Date[Date]` → `orders[order_date]`

---

## 📐 DAX Measures

### ── REVENUE MEASURES ──────────────────────────────────────

```dax
Total Revenue =
CALCULATE(
    SUMX(orders, orders[order_total]),
    orders[status] <> "Cancelled"
)

Total Orders =
CALCULATE(
    DISTINCTCOUNT(orders[order_id]),
    orders[status] <> "Cancelled"
)

Unique Customers =
CALCULATE(
    DISTINCTCOUNT(orders[customer_id]),
    orders[status] <> "Cancelled"
)

Average Order Value =
DIVIDE([Total Revenue], [Total Orders], 0)

Total Units Sold =
CALCULATE(
    SUM(order_items[quantity]),
    orders[status] <> "Cancelled"
)

Total Gross Profit =
CALCULATE(
    SUMX(
        order_items,
        order_items[line_total] - RELATED(products[cost_price]) * order_items[quantity]
    ),
    orders[status] <> "Cancelled"
)

Gross Profit Margin % =
DIVIDE([Total Gross Profit], [Total Revenue], 0)
```

### ── GROWTH MEASURES ───────────────────────────────────────

```dax
Revenue LY =
CALCULATE(
    [Total Revenue],
    SAMEPERIODLASTYEAR('Date'[Date])
)

Revenue YoY Growth % =
DIVIDE([Total Revenue] - [Revenue LY], [Revenue LY], 0)

Revenue MTD =
CALCULATE([Total Revenue], DATESMTD('Date'[Date]))

Revenue YTD =
CALCULATE([Total Revenue], DATESYTD('Date'[Date]))

Revenue Prev Month =
CALCULATE([Total Revenue], PREVIOUSMONTH('Date'[Date]))

MoM Growth % =
DIVIDE([Total Revenue] - [Revenue Prev Month], [Revenue Prev Month], 0)

Running Total Revenue =
CALCULATE(
    [Total Revenue],
    DATESYTD('Date'[Date])
)
```

### ── CUSTOMER MEASURES ─────────────────────────────────────

```dax
New Customers =
VAR _firstOrders =
    ADDCOLUMNS(
        VALUES(orders[customer_id]),
        "FirstOrder", CALCULATE(MIN(orders[order_date]))
    )
RETURN
    COUNTROWS(
        FILTER(
            _firstOrders,
            [FirstOrder] >= MIN('Date'[Date]) &&
            [FirstOrder] <= MAX('Date'[Date])
        )
    )

Returning Customers =
[Unique Customers] - [New Customers]

Customer Retention Rate % =
DIVIDE([Returning Customers], [Unique Customers], 0)

Avg Customer Lifetime Value =
DIVIDE([Total Revenue], DISTINCTCOUNT(customers[customer_id]), 0)

Champions Count =
CALCULATE(
    DISTINCTCOUNT(orders[customer_id]),
    -- Join with RFM table if loaded
    -- rfm[segment] = "Champions"
)
```

### ── RETURN MEASURES ───────────────────────────────────────

```dax
Total Returns =
COUNTROWS(returns)

Total Refunded Amount =
SUM(returns[refund_amount])

Return Rate % =
DIVIDE(
    [Total Returns],
    CALCULATE(
        DISTINCTCOUNT(orders[order_id]),
        orders[status] = "Delivered"
    ),
    0
)

Avg Refund Amount =
DIVIDE([Total Refunded Amount], [Total Returns], 0)
```

### ── OPERATIONAL MEASURES ─────────────────────────────────

```dax
Cancellation Rate % =
DIVIDE(
    CALCULATE(COUNTROWS(orders), orders[status] = "Cancelled"),
    COUNTROWS(orders),
    0
)

Avg Delivery Days =
AVERAGEX(
    FILTER(orders, orders[status] = "Delivered"),
    DATEDIFF(orders[order_date], orders[delivery_date], DAY)
)

Revenue Per Customer =
DIVIDE([Total Revenue], [Unique Customers], 0)

Coupon Usage Rate % =
DIVIDE(
    CALCULATE(COUNTROWS(orders), orders[coupon_used] = 1),
    [Total Orders],
    0
)
```

---

## 📊 Dashboard Pages (Recommended Layout)

### Page 1 — Executive Overview
- **KPI Cards**: Total Revenue | Total Orders | AOV | Return Rate | Cancellation Rate
- **Line Chart**: Monthly Revenue (2022-2024) with YoY overlay
- **Bar Chart**: Revenue by Channel
- **Donut**: Order Status breakdown
- **Slicer**: Year | Quarter | Country

### Page 2 — Product Analytics
- **Bar Chart**: Top 10 Products by Revenue
- **Treemap**: Revenue by Category
- **Scatter Plot**: Rating vs Revenue (size = units sold)
- **Table**: Product details with conditional formatting
- **Slicer**: Category | Brand

### Page 3 — Customer Analytics
- **Bar Chart**: RFM Segment distribution
- **Map Visual**: Revenue by Country/City
- **Funnel**: Buyer Lifecycle (One-Time → VIP)
- **Line Chart**: New vs Returning customers monthly
- **Matrix**: Age Group × Gender revenue

### Page 4 — Returns & Operations
- **KPI Cards**: Return Rate | Total Refunded | Avg Days to Return
- **Bar Chart**: Return Reasons
- **Line Chart**: Return Rate trend monthly
- **Table**: Countries with highest return rates
- **Gauge**: Delivery performance vs target

### Page 5 — Cohort Analysis
- **Matrix**: Cohort Retention Heatmap (conditional formatting)
- **Line Chart**: Retention by cohort class over months

---

## 🎨 Theme Suggestions
- Primary: `#0D1B2A` (Dark Navy)
- Secondary: `#1B5E8B` (Mid Blue)
- Accent 1: `#00B4D8` (Teal)
- Accent 2: `#2DC653` (Green)
- Warning: `#F4A261` (Amber)
- Danger: `#E63946` (Red)
- Background: `#F0F4F8`
- Font: Segoe UI / Calibri

Import theme JSON from `powerbi/theme.json` in this project.
