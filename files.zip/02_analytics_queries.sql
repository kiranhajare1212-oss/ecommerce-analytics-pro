-- ============================================================
-- E-COMMERCE ANALYTICS PROJECT
-- File: 02_analytics_queries.sql
-- Purpose: Core business analytics queries
-- ============================================================

-- ════════════════════════════════════════════════════════════
-- SECTION A: REVENUE & SALES ANALYTICS
-- ════════════════════════════════════════════════════════════

-- A1: Monthly Revenue & Order Trends
-- ────────────────────────────────────
SELECT
    strftime('%Y', order_date)          AS year,
    strftime('%m', order_date)          AS month,
    strftime('%Y-%m', order_date)       AS year_month,
    COUNT(DISTINCT order_id)            AS total_orders,
    COUNT(DISTINCT customer_id)         AS unique_customers,
    ROUND(SUM(order_total), 2)          AS gross_revenue,
    ROUND(SUM(shipping_fee), 2)         AS shipping_revenue,
    ROUND(AVG(order_total), 2)          AS avg_order_value,
    SUM(coupon_used)                    AS coupons_redeemed
FROM orders
WHERE status != 'Cancelled'
GROUP BY year, month
ORDER BY year, month;


-- A2: Revenue by Product Category (with Margin)
-- ───────────────────────────────────────────────
SELECT
    p.category,
    COUNT(DISTINCT oi.order_id)                                         AS orders_count,
    SUM(oi.quantity)                                                     AS units_sold,
    ROUND(SUM(oi.line_total), 2)                                         AS revenue,
    ROUND(SUM(oi.quantity * p.cost_price), 2)                           AS cogs,
    ROUND(SUM(oi.line_total) - SUM(oi.quantity * p.cost_price), 2)      AS gross_profit,
    ROUND(
      (SUM(oi.line_total) - SUM(oi.quantity * p.cost_price))
      / NULLIF(SUM(oi.line_total), 0) * 100, 2)                         AS gp_margin_pct
FROM order_items oi
JOIN products     p  ON oi.product_id  = p.product_id
JOIN orders       o  ON oi.order_id    = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY p.category
ORDER BY revenue DESC;


-- A3: Top 20 Best-Selling Products
-- ──────────────────────────────────
SELECT
    p.product_id,
    p.product_name,
    p.category,
    p.brand,
    SUM(oi.quantity)               AS units_sold,
    ROUND(SUM(oi.line_total), 2)   AS revenue,
    ROUND(AVG(oi.discount_pct)*100,1) AS avg_discount_pct,
    p.rating,
    p.reviews_count
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders   o ON oi.order_id   = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY p.product_id, p.product_name, p.category, p.brand, p.rating, p.reviews_count
ORDER BY units_sold DESC
LIMIT 20;


-- A4: Sales Channel Performance
-- ───────────────────────────────
SELECT
    channel,
    COUNT(DISTINCT order_id)          AS orders,
    COUNT(DISTINCT customer_id)       AS customers,
    ROUND(SUM(order_total), 2)        AS revenue,
    ROUND(AVG(order_total), 2)        AS avg_order_value,
    ROUND(SUM(order_total) * 100.0
          / SUM(SUM(order_total)) OVER (), 2) AS revenue_share_pct
FROM orders
WHERE status != 'Cancelled'
GROUP BY channel
ORDER BY revenue DESC;


-- A5: Payment Method Mix
-- ───────────────────────
SELECT
    payment_method,
    COUNT(*)                          AS transactions,
    ROUND(SUM(order_total), 2)        AS revenue,
    ROUND(AVG(order_total), 2)        AS avg_order_value,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS txn_share_pct
FROM orders
WHERE status != 'Cancelled'
GROUP BY payment_method
ORDER BY transactions DESC;


-- ════════════════════════════════════════════════════════════
-- SECTION B: CUSTOMER ANALYTICS (RFM + COHORTS)
-- ════════════════════════════════════════════════════════════

-- B1: Customer Lifetime Value (CLV)
-- ───────────────────────────────────
WITH customer_stats AS (
    SELECT
        o.customer_id,
        c.first_name || ' ' || c.last_name AS customer_name,
        c.city,
        c.country,
        c.acquisition_channel,
        c.age_group,
        c.gender,
        MIN(o.order_date)               AS first_order_date,
        MAX(o.order_date)               AS last_order_date,
        COUNT(DISTINCT o.order_id)      AS total_orders,
        ROUND(SUM(o.order_total), 2)    AS total_revenue,
        ROUND(AVG(o.order_total), 2)    AS avg_order_value,
        julianday(MAX(o.order_date))
          - julianday(MIN(o.order_date)) AS customer_lifespan_days
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.status != 'Cancelled'
    GROUP BY o.customer_id, customer_name, c.city, c.country,
             c.acquisition_channel, c.age_group, c.gender
)
SELECT
    *,
    CASE
        WHEN total_orders = 1              THEN 'One-Time Buyer'
        WHEN total_orders BETWEEN 2 AND 4  THEN 'Occasional Buyer'
        WHEN total_orders BETWEEN 5 AND 9  THEN 'Regular Buyer'
        ELSE 'VIP Buyer'
    END AS buyer_segment,
    CASE
        WHEN total_revenue >= 50000        THEN 'Platinum'
        WHEN total_revenue >= 20000        THEN 'Gold'
        WHEN total_revenue >= 5000         THEN 'Silver'
        ELSE 'Bronze'
    END AS value_tier
FROM customer_stats
ORDER BY total_revenue DESC;


-- B2: RFM Segmentation
-- ─────────────────────
WITH rfm_base AS (
    SELECT
        customer_id,
        CAST(julianday('2025-01-01') - julianday(MAX(order_date)) AS INTEGER) AS recency_days,
        COUNT(DISTINCT order_id)      AS frequency,
        ROUND(SUM(order_total), 2)    AS monetary
    FROM orders
    WHERE status != 'Cancelled'
    GROUP BY customer_id
),
rfm_scores AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days DESC)  AS r_score,  -- lower recency = better
        NTILE(5) OVER (ORDER BY frequency ASC)       AS f_score,
        NTILE(5) OVER (ORDER BY monetary ASC)        AS m_score
    FROM rfm_base
),
rfm_segments AS (
    SELECT *,
        (r_score + f_score + m_score) AS rfm_total,
        CASE
            WHEN r_score >= 4 AND f_score >= 4 THEN 'Champions'
            WHEN r_score >= 3 AND f_score >= 3 THEN 'Loyal Customers'
            WHEN r_score >= 4 AND f_score <= 2 THEN 'Recent Customers'
            WHEN r_score <= 2 AND f_score >= 3 THEN 'At Risk'
            WHEN r_score <= 2 AND f_score <= 2 THEN 'Lost Customers'
            WHEN m_score >= 4                   THEN 'High Spenders'
            ELSE 'Potential Loyalists'
        END AS segment
    FROM rfm_scores
)
SELECT
    segment,
    COUNT(*)                          AS customers,
    ROUND(AVG(recency_days), 0)       AS avg_recency_days,
    ROUND(AVG(frequency), 1)          AS avg_frequency,
    ROUND(AVG(monetary), 2)           AS avg_monetary,
    ROUND(SUM(monetary), 2)           AS total_revenue
FROM rfm_segments
GROUP BY segment
ORDER BY total_revenue DESC;


-- B3: New vs Returning Customers Monthly
-- ───────────────────────────────────────
WITH first_orders AS (
    SELECT customer_id, MIN(order_date) AS first_order_date
    FROM orders WHERE status != 'Cancelled'
    GROUP BY customer_id
)
SELECT
    strftime('%Y-%m', o.order_date)   AS year_month,
    COUNT(DISTINCT CASE WHEN o.order_date = fo.first_order_date
                        THEN o.customer_id END) AS new_customers,
    COUNT(DISTINCT CASE WHEN o.order_date > fo.first_order_date
                        THEN o.customer_id END) AS returning_customers,
    COUNT(DISTINCT o.customer_id)               AS total_customers
FROM orders o
JOIN first_orders fo ON o.customer_id = fo.customer_id
WHERE o.status != 'Cancelled'
GROUP BY year_month
ORDER BY year_month;


-- B4: Customer Cohort Retention (Monthly)
-- ─────────────────────────────────────────
WITH cohort_base AS (
    SELECT
        customer_id,
        strftime('%Y-%m', MIN(order_date)) AS cohort_month
    FROM orders WHERE status != 'Cancelled'
    GROUP BY customer_id
),
order_cohorts AS (
    SELECT
        o.customer_id,
        cb.cohort_month,
        strftime('%Y-%m', o.order_date) AS order_month,
        (strftime('%Y', o.order_date) - strftime('%Y', cb.cohort_month)) * 12
         + (strftime('%m', o.order_date) - strftime('%m', cb.cohort_month))
         AS month_number
    FROM orders o
    JOIN cohort_base cb ON o.customer_id = cb.customer_id
    WHERE o.status != 'Cancelled'
)
SELECT
    cohort_month,
    month_number,
    COUNT(DISTINCT customer_id) AS customers,
    COUNT(DISTINCT customer_id) * 100.0
        / FIRST_VALUE(COUNT(DISTINCT customer_id))
          OVER (PARTITION BY cohort_month ORDER BY month_number)  AS retention_rate
FROM order_cohorts
GROUP BY cohort_month, month_number
ORDER BY cohort_month, month_number;


-- ════════════════════════════════════════════════════════════
-- SECTION C: GEOGRAPHY & DEMOGRAPHICS
-- ════════════════════════════════════════════════════════════

-- C1: Revenue by Country
SELECT
    o.country,
    COUNT(DISTINCT o.customer_id)   AS customers,
    COUNT(DISTINCT o.order_id)      AS orders,
    ROUND(SUM(o.order_total), 2)    AS revenue,
    ROUND(AVG(o.order_total), 2)    AS avg_order_value
FROM orders o
WHERE o.status != 'Cancelled'
GROUP BY o.country
ORDER BY revenue DESC;


-- C2: Revenue by City (Top 20)
SELECT
    o.city,
    o.country,
    COUNT(DISTINCT o.order_id)    AS orders,
    ROUND(SUM(o.order_total), 2)  AS revenue
FROM orders o
WHERE o.status != 'Cancelled'
GROUP BY o.city, o.country
ORDER BY revenue DESC
LIMIT 20;


-- C3: Demographics Analysis
SELECT
    c.age_group,
    c.gender,
    COUNT(DISTINCT c.customer_id)       AS customers,
    COUNT(DISTINCT o.order_id)          AS orders,
    ROUND(SUM(o.order_total), 2)        AS revenue,
    ROUND(AVG(o.order_total), 2)        AS avg_order_value
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
    AND o.status != 'Cancelled'
GROUP BY c.age_group, c.gender
ORDER BY c.age_group, c.gender;


-- ════════════════════════════════════════════════════════════
-- SECTION D: OPERATIONAL KPIs
-- ════════════════════════════════════════════════════════════

-- D1: Order Status Distribution
SELECT
    status,
    COUNT(*)                     AS order_count,
    ROUND(COUNT(*) * 100.0
          / SUM(COUNT(*)) OVER (), 2) AS pct_of_total,
    ROUND(SUM(order_total), 2)   AS revenue_at_risk
FROM orders
GROUP BY status
ORDER BY order_count DESC;


-- D2: Average Delivery Time by Country
SELECT
    country,
    COUNT(DISTINCT order_id)                                AS delivered_orders,
    ROUND(AVG(julianday(delivery_date) - julianday(order_date)), 1) AS avg_delivery_days,
    MIN(julianday(delivery_date) - julianday(order_date))   AS min_days,
    MAX(julianday(delivery_date) - julianday(order_date))   AS max_days
FROM orders
WHERE status = 'Delivered'
  AND delivery_date IS NOT NULL
GROUP BY country
ORDER BY avg_delivery_days;


-- D3: Return Rate Analysis
SELECT
    p.category,
    COUNT(DISTINCT oi.order_id)                     AS total_orders,
    COUNT(DISTINCT r.order_id)                      AS returned_orders,
    ROUND(COUNT(DISTINCT r.order_id) * 100.0
          / NULLIF(COUNT(DISTINCT oi.order_id), 0), 2) AS return_rate_pct,
    ROUND(SUM(r.refund_amount), 2)                  AS total_refunds
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders   o ON oi.order_id   = o.order_id
LEFT JOIN returns r ON r.order_id = o.order_id
WHERE o.status = 'Delivered'
GROUP BY p.category
ORDER BY return_rate_pct DESC;


-- D4: Return Reasons Breakdown
SELECT
    reason,
    COUNT(*)                      AS return_count,
    ROUND(SUM(refund_amount), 2)  AS total_refunded,
    ROUND(AVG(refund_amount), 2)  AS avg_refund
FROM returns
GROUP BY reason
ORDER BY return_count DESC;


-- D5: Inventory Health Check (Low Stock Alert)
SELECT
    product_id,
    product_name,
    category,
    brand,
    stock_quantity,
    selling_price,
    CASE
        WHEN stock_quantity = 0         THEN 'Out of Stock'
        WHEN stock_quantity < 10        THEN 'Critical'
        WHEN stock_quantity < 50        THEN 'Low Stock'
        ELSE 'Healthy'
    END AS stock_status
FROM products
WHERE is_active = 1
ORDER BY stock_quantity ASC;


-- ════════════════════════════════════════════════════════════
-- SECTION E: ADVANCED / WINDOW FUNCTIONS
-- ════════════════════════════════════════════════════════════

-- E1: Running Revenue (Year-to-Date by Month)
SELECT
    strftime('%Y-%m', order_date)                    AS year_month,
    ROUND(SUM(order_total), 2)                        AS monthly_revenue,
    ROUND(SUM(SUM(order_total)) OVER (
        PARTITION BY strftime('%Y', order_date)
        ORDER BY strftime('%Y-%m', order_date)
    ), 2)                                             AS ytd_revenue,
    ROUND(LAG(SUM(order_total)) OVER (
        ORDER BY strftime('%Y-%m', order_date)
    ), 2)                                             AS prev_month_revenue,
    ROUND((SUM(order_total) - LAG(SUM(order_total)) OVER (
        ORDER BY strftime('%Y-%m', order_date)
    )) * 100.0 / NULLIF(LAG(SUM(order_total)) OVER (
        ORDER BY strftime('%Y-%m', order_date)
    ), 0), 2)                                         AS mom_growth_pct
FROM orders
WHERE status != 'Cancelled'
GROUP BY year_month
ORDER BY year_month;


-- E2: Product Category Revenue Rank per Month
SELECT
    strftime('%Y-%m', o.order_date) AS year_month,
    p.category,
    ROUND(SUM(oi.line_total), 2)    AS revenue,
    RANK() OVER (
        PARTITION BY strftime('%Y-%m', o.order_date)
        ORDER BY SUM(oi.line_total) DESC
    )                               AS rank_in_month
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders   o ON oi.order_id   = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY year_month, p.category
ORDER BY year_month, rank_in_month;


-- E3: Customer Purchase Gap Analysis (Days Between Orders)
WITH ordered_purchases AS (
    SELECT
        customer_id,
        order_date,
        LAG(order_date) OVER (
            PARTITION BY customer_id ORDER BY order_date
        ) AS prev_order_date
    FROM orders
    WHERE status != 'Cancelled'
)
SELECT
    customer_id,
    ROUND(AVG(julianday(order_date) - julianday(prev_order_date)), 1) AS avg_days_between_orders,
    MIN(julianday(order_date) - julianday(prev_order_date))           AS min_gap_days,
    MAX(julianday(order_date) - julianday(prev_order_date))           AS max_gap_days
FROM ordered_purchases
WHERE prev_order_date IS NOT NULL
GROUP BY customer_id
HAVING COUNT(*) >= 2
ORDER BY avg_days_between_orders;


-- E4: Discount Impact on Revenue
SELECT
    CASE
        WHEN oi.discount_pct = 0     THEN 'No Discount'
        WHEN oi.discount_pct <= 0.05 THEN '1-5%'
        WHEN oi.discount_pct <= 0.10 THEN '6-10%'
        WHEN oi.discount_pct <= 0.15 THEN '11-15%'
        ELSE '16-20%'
    END                               AS discount_band,
    COUNT(DISTINCT oi.item_id)        AS line_items,
    SUM(oi.quantity)                  AS units_sold,
    ROUND(SUM(oi.line_total), 2)      AS actual_revenue,
    ROUND(SUM(oi.unit_price * oi.quantity), 2) AS full_price_revenue,
    ROUND(SUM(oi.unit_price * oi.quantity)
          - SUM(oi.line_total), 2)    AS revenue_foregone
FROM order_items oi
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY discount_band
ORDER BY oi.discount_pct;
